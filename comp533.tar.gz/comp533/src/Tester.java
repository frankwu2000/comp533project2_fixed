import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlOption;
import com.gargoylesoftware.htmlunit.html.HtmlInput;
import com.gargoylesoftware.htmlunit.html.HtmlForm;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.HtmlAnchor;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import com.gargoylesoftware.htmlunit.html.HtmlSelect;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;

public class Tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//get page
/*
		String searchQuery = "Iphone 6s" ;

		WebClient client = new WebClient();  
	
		try {  
		  String searchUrl = "https://www.isi.edu/~gil/";
		  HtmlPage page = client.getPage(searchUrl);
		  System.out.println(page.asXml());
		}catch(Exception e){
		  e.printStackTrace();
		}
		*/
		//download
		/*
		String url="https://raw.githubusercontent.com/arthursdays/UberBasedCitibikeCirculatingSystem/master/README.md";
		String fileLocation="/home/ken/t.txt";
		 try {

	            URL website = new URL(url);
	            ReadableByteChannel rbc = Channels.newChannel(website.openStream());
	            FileOutputStream fos = new FileOutputStream(fileLocation);
	            fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
	            fos.close();
	            rbc.close();

	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        */
		 //login
		/*
		String baseUrl="https://news.ycombinator.com/";
		 String loginUrl="https://news.ycombinator.com/login?goto=news";
	     String login = "login";
	        String password = "password" ;

	        try {
	            System.out.println("Starting autoLogin on " + loginUrl);
	            WebClient client = autoLogin(loginUrl, login, password);
	            HtmlPage page = client.getPage(baseUrl) ;

	            HtmlAnchor logoutLink = page.getFirstByXPath(String.format("//a[@href='user?id=%s']", login)) ;
	            if(logoutLink != null ){
	                System.out.println("Successfuly logged in !");
	                // printing the cookies
///	                for(Cookie cookie : client.getCookieManager().getCookies()){
	//                    System.out.println(cookie.toString());
	  //              }
	            }else{
	                System.err.println("Wrong credentials");
	            }

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        */
		//content process
			String searchQuery = "Iphone 6s" ;

		WebClient client = new WebClient();  
	
		try {  
		  String searchUrl = "https://offcampuslistings.ca/33845-apartment-3440-rue-durocher.html/";
		  HtmlPage page = client.getPage(searchUrl);
		  //HtmlElement item =((HtmlElement) htmlItem.getFirstByXPath(".//span[@class='result-price']")) ;
		  HtmlElement item =page.getHtmlElementById("colGauche");
		  item=item.getFirstByXPath("//h1");
		  System.out.println(item.asText());
		}catch(Exception e){
		  e.printStackTrace();
		}
	
	}
	public static WebClient autoLogin(String loginUrl, String login, String password) throws  IOException{
        WebClient client = new WebClient();
        client.getOptions().setCssEnabled(false);
        client.getOptions().setJavaScriptEnabled(false);

        HtmlPage page = client.getPage(loginUrl);

        HtmlInput inputPassword = page.getFirstByXPath("//input[@type='password']");
        //The first preceding input that is not hidden
        HtmlInput inputLogin = inputPassword.getFirstByXPath(".//preceding::input[not(@type='hidden')]");

        inputLogin.setValueAttribute(login);
        inputPassword.setValueAttribute(password);

        //get the enclosing form
        HtmlForm loginForm = inputPassword.getEnclosingForm() ;

        //submit the form
        page = client.getPage(loginForm.getWebRequest(null));

        //returns the cookie filled client :)
        return client;
    }
	
	}

